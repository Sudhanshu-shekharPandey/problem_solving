#include<stdio.h>
void main()
{
    int b,area ;
    float h;
    printf("Enter the base and area:");
    scanf("%d %d",&b,&area);
    h=(2*area)/b;
    printf("%f",h);
}
